package com.example.android.booklisting;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import java.util.List;

/**
 * Created by eachunn on 12/23/16.
 */

public class VolumeAdapter extends ArrayAdapter {

        public VolumeAdapter(Context context, List<Volume> volumes) {
            super(context, 0, volumes);
        }


        //Returns a list item view with the desired volume information in the list of volumes
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {


            //Check to see if there is an existing list item view to add, otherwise, create a new layout
            View listItemView = convertView;
            if (listItemView == null) {
                listItemView = LayoutInflater.from(getContext()).inflate(
                        R.layout.list_item, parent, false);
            }

            Volume currentVolume = (Volume) getItem(position);

            // Find the TextView with ID title
            TextView titleView = (TextView) listItemView.findViewById(R.id.title);

            // Set the title of the current volume in the TextView
            titleView.setText(currentVolume.getTitle());

            // Find the TextView with ID author
            TextView authorView = (TextView) listItemView.findViewById(R.id.author);

            // Set the author of the current volume in that TextView
            authorView.setText(currentVolume.getAuthor());

            // Return the list item view with information
            return listItemView;
        }

}

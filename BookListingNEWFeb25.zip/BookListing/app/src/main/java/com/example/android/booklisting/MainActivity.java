package com.example.android.booklisting;

import android.app.LoaderManager;
import android.content.Context;

import android.content.Loader;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import static com.example.android.booklisting.QueryUtils.fetchVolumeQueryResults;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<List<Volume>> {

    private static final int VOLUME_LOADER_ID = 1; // Index for Loader
    private final String url_start = "https://www.googleapis.com/books/v1/volumes?q="; // Stem of URL for search
    public String final_url; // GET request to Google Book API
    private TextView mEmptyStateTextView; //Empty message
    private EditText mEdit; // Text box
    private String mQuery; // Search term
    private VolumeAdapter mAdapter; // Container for responses

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Find the empty list in the layout
        ListView volumeListView = (ListView) findViewById(R.id.list);

        mEmptyStateTextView = (TextView) findViewById(R.id.empty_view);

        //Sets EmptyView on the ListView
        volumeListView.setEmptyView(mEmptyStateTextView);

        //Create adapter to hold Volume data type
        mAdapter = new VolumeAdapter(this, new ArrayList<Volume>());

        // Link the Adapter and the List
        volumeListView.setAdapter(mAdapter);

        final Button button = (Button) findViewById(R.id.search_button);
        button.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                getLoaderManager().restartLoader(VOLUME_LOADER_ID, null, MainActivity.this);

                // Find the search field
                mEdit = (EditText) findViewById(R.id.search_field);

                // Assign text in search field to member variable
                mQuery = mEdit.getText().toString();

                // Concatenate stem URL with search field to creat request URL
                final_url = url_start + mQuery;


                // Creates inner class to extend async task to perform connection to the internet
                class SearchAsync extends AsyncTask<Object, Void, Object> {

                    @Override
                    protected Object doInBackground(Object[] objects) {
                        fetchVolumeQueryResults(final_url);
                        return final_url;
                    }

                    @Override
                    protected void onPostExecute(Object final_url) {
                        //restarts volume Loader to renew content

                        if (mEdit != null) {
                            mEmptyStateTextView = (TextView) findViewById(R.id.empty_view);
                            mEmptyStateTextView.setVisibility(View.INVISIBLE);
                        } else if (mEdit == null || final_url == null) {
                            mEmptyStateTextView = (TextView) findViewById(R.id.empty_view);
                            mEmptyStateTextView.setText(R.string.no_volumes);
                            mEmptyStateTextView.setVisibility(View.VISIBLE);

                        }

                    }
                }

                // Action on Button
                ConnectivityManager connMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

                NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();

                if (networkInfo != null && networkInfo.isConnected()) {

                    LoaderManager loaderManager = getLoaderManager();

                    loaderManager.initLoader(VOLUME_LOADER_ID, null, MainActivity.this);

                    new SearchAsync().execute(final_url);

                } else if (networkInfo == null) {
                    mEmptyStateTextView = (TextView) findViewById(R.id.empty_view);
                    mEmptyStateTextView.setText(R.string.no_internet_connection);

                }



                // Performs async task
               if (networkInfo != null && networkInfo.isConnected()) {
                   new SearchAsync().execute(final_url);
                }

            }

        });

    }


    @Override
    public Loader<List<Volume>> onCreateLoader(int i, Bundle bundle) {

        return new VolumeLoader(this, final_url);
    }

    @Override
    public void onLoadFinished(Loader<List<Volume>> loader, List<Volume> volumes) {


        mAdapter.clear();

        if (volumes != null && !volumes.isEmpty()) {
            mAdapter.addAll(volumes);
        }

    }

    @Override
    public void onLoaderReset(Loader<List<Volume>> loader) {

        mAdapter.clear();
    }


}


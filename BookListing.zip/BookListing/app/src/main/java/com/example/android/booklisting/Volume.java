package com.example.android.booklisting;
/**
 * Created by eachunn on 12/30/16.
 */

public class Volume {


    // Author of the Volume
    private String mAuthor;

    // Title of the Volume
    private String mTitle;


    public Volume(String author, String title) {
        mAuthor = author;
        mTitle = title;
    }

    // Returns Author
    public String getAuthor() {return mAuthor;}

    // Returns Title
    public String getTitle() {return mTitle;}

}


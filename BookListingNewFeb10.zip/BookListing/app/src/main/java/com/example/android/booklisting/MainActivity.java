package com.example.android.booklisting;

import android.app.LoaderManager;
import android.content.Context;

import android.content.Loader;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

import static com.example.android.booklisting.QueryUtils.fetchVolumeQueryResults;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<List<Volume>> {

    private static final int VOLUME_LOADER_ID = 1;
    private final String url_start = "https://www.googleapis.com/books/v1/volumes?q=";
    private EditText mEdit;
    private String mQuery;
    public String final_url;


    private VolumeAdapter mAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Find the empty list in the layout
        ListView volumeListView = (ListView) findViewById(R.id.list);


        //Create adapter to hold Volume data type
        mAdapter = new VolumeAdapter(this, new ArrayList<Volume>());

        // Link the Adapter and the List
        volumeListView.setAdapter(mAdapter);


        ConnectivityManager connMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();

        if (networkInfo != null && networkInfo.isConnected()) {

            LoaderManager loaderManager = getLoaderManager();

            loaderManager.initLoader(VOLUME_LOADER_ID, null, this);

        }

        final Button button = (Button) findViewById(R.id.search_button);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Action on Button

                mEdit = (EditText) findViewById(R.id.search_field);

                mQuery = mEdit.getText().toString();
                final_url = url_start + mQuery;

                fetchVolumeQueryResults(final_url);

                getLoaderManager().restartLoader(VOLUME_LOADER_ID, null, MainActivity.this);

            }
        });

    }

    @Override
    public Loader<List<Volume>> onCreateLoader(int i, Bundle bundle) {

        return new VolumeLoader(this, final_url);
    }

    @Override
    public void onLoadFinished(Loader<List<Volume>> loader, List<Volume> volumes) {


        if (volumes != null && !volumes.isEmpty()) {
            mAdapter.addAll(volumes);
        }

    }

    @Override
    public void onLoaderReset(Loader<List<Volume>> loader) {

        mAdapter.clear();
    }


}


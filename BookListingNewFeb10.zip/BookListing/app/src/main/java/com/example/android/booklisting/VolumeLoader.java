package com.example.android.booklisting;

/**
 * Created by eachunn on 12/16/16.
 */

import android.content.AsyncTaskLoader;
import android.content.Context;
import android.util.Log;

import java.util.List;


public class VolumeLoader extends AsyncTaskLoader<List<Volume>> {

    private static final String LOG_TAG = VolumeLoader.class.getName();
    
    private String mUrl;
    
    public VolumeLoader(Context context, String url) {
        super(context);
        mUrl = url;
    }

    @Override
    protected void onStartLoading() {
        Log.i(LOG_TAG, "TEST: onStartLoading called ...");
        forceLoad();
    }

    @Override
    public List<Volume> loadInBackground(){
        Log.i(LOG_TAG, "TEST: loadInBackground() called... ");

        if(mUrl == null) {
            return null;
        }

        List<Volume> volumes = QueryUtils.fetchVolumeQueryResults(mUrl);

        return volumes;
    }


}
